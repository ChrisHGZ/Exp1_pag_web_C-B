var slideIndex = 1;
showSlides(slideIndex);

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("slide");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].classList.remove("active");  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].classList.remove("active");
  }
  slides[slideIndex-1].classList.add("active");  
  dots[slideIndex-1].classList.add("active");
}


function showInfo(name, description, price, event) {
  document.getElementById('photoName').innerText = 'Nombre: ' + name;
  document.getElementById('photoDescription').innerText = 'Descripción: ' + description;
  document.getElementById('photoPrice').innerText = 'Precio: ' + price;
  var photoInfo = document.getElementById('photoInfo');
  photoInfo.style.display = 'block';
  // Ajustar la posición de la ventana emergente cerca de la imagen seleccionada
  var photo = event.currentTarget.getBoundingClientRect();
  photoInfo.style.top = (photo.top + window.pageYOffset) + 'px'; // Ajustar por la posición de desplazamiento vertical de la ventana
  photoInfo.style.left = photo.left + 'px';
}

function hideInfo() {
  document.getElementById('photoInfo').style.display = 'none';
}